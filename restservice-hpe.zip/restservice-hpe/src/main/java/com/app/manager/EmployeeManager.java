package com.app.manager;

import com.app.model.Employee;
import com.app.model.Employees;

import java.util.Arrays;

public class EmployeeManager {

    public Employees getEmployees() {
        Employees employees = new Employees();
        
        // Hardcoding 3-4 employees
        employees.setEmployeeList(Arrays.asList(
            new Employee("1", "John", "Doe", "john.doe@example.com", "Software Engineer"),
            new Employee("2", "Jane", "Smith", "jane.smith@example.com", "Product Manager"),
            new Employee("3", "Alice", "Johnson", "alice.johnson@example.com", "UX Designer")
        ));
        
        return employees;
    }
}
