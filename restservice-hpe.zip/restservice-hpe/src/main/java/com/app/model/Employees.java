package com.app.model;

import java.util.List;

public class Employees {
    private List<Employee> employeeList;

    // Getter and setter for employee list
    public List<Employee> getEmployeeList() {
        return employeeList;
    }

    
    public void setEmployeeList(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }
}
